from __future__ import annotations

import argparse
import json
import os
import sys
import traceback
from pathlib import Path

from rich.console import Console
from rich.table import Table

from . import links
from .audit import run_audit
from .clone import CloneError, clone_repo
from .config import Config
from .db import DB
from .discover import run_discovery
from .docs_hunt import hunt
from .intel import detect_stack, find_prior_audits, first_deployment_address, gather
from .poc import generate
from .report import write_index, write_reports
from .target import intake, save_scope
from .util import (BANNER, make_session, project_dir, repo_stats, resolve_workspace,
                   setup_logging, slugify)

console = Console()
RULES_DIR = Path(__file__).parent / "audit"


def _ctx(args):
    cfg = Config.load(args.config)
    setup_logging(args.verbose)
    workspace = resolve_workspace(cfg)
    return cfg, workspace, DB(workspace / "bountyhunter.db"), make_session(
        cfg.rate_limit_rps, cfg.request_timeout, cfg.user_agent)


def _resolve(db, ident: str):
    p = db.get_project(ident)
    if not p:
        console.print(f"[red]no project matching[/] {ident!r}")
        sys.exit(2)
    return p


def _tool_table(name: str, tools_report: list) -> Table:
    t = Table(title=f"{name} - tool status")
    t.add_column("tool")
    t.add_column("status")
    for t_ in tools_report:
        st = str(t_.get("status", "?"))
        colour = "green" if st == "ok" else "red" if ("missing" in st or "rc=" in st or "crash" in st) else "yellow"
        t.add_row(str(t_.get("tool", "?")), f"[{colour}]{st}[/]")
    return t


def cmd_discover(args):
    cfg, workspace, db, session = _ctx(args)
    for kw in (args.keyword or cfg.keywords):
        console.print(f"[cyan]discovering[/] {kw}")
        r = run_discovery(cfg, db, session, kw, use_x=not args.no_x)
        for src, status in r["sources"].items():
            console.print(f"  {src}: {status}")
    out = workspace / "discovery-links.md"
    out.write_text("\n".join(f"- [{l['label']}]({l['url']})" for l in db.links()), encoding="utf-8")
    console.print(f"[green]links ->[/] {out}")


def cmd_links(args):
    cfg, workspace, db, _ = _ctx(args)
    out = workspace / f"links-{slugify(args.keyword)}.md"
    out.write_text("\n".join(f"- [{l['label']}]({l['url']})"
                             for l in links.for_keyword(args.keyword)), encoding="utf-8")
    console.print(f"[green]->[/] {out}")


def cmd_list(args):
    cfg, workspace, db, _ = _ctx(args)
    rows = db.list_projects(args.status)
    t = Table(title=f"{len(rows)} projects")
    for c in ("ID", "Platform", "Name", "Repo", "Status"):
        t.add_column(c, overflow="fold")
    for p in rows:
        t.add_row(str(p["id"]), p["platform"], (p["name"] or p["slug"])[:52],
                  (p["repo_url"] or "-")[:52], p["status"])
    console.print(t)


def cmd_show(args):
    cfg, workspace, db, session = _ctx(args)
    p = _resolve(db, args.id)
    intel = gather(cfg, session, p, workspace)
    console.print_json(json.dumps({**dict(p), "intel": intel}, indent=2, default=str))
    if intel["repo_url"]:
        db.upsert_project(p["platform"], p["slug"], repo_url=intel["repo_url"], status="intel")


def cmd_clone(args):
    cfg, workspace, db, session = _ctx(args)
    p = _resolve(db, args.id)
    if not p["repo_url"]:
        intel = gather(cfg, session, p, workspace)
        if not intel["repo_url"]:
            console.print("[red]no repo resolvable[/]")
            sys.exit(1)
        db.upsert_project(p["platform"], p["slug"], repo_url=intel["repo_url"])
        p = db.get_project(args.id)
    dest = project_dir(workspace, p["platform"], p["slug"]) / "repo" / "src"
    try:
        clone_repo(p["repo_url"], None, dest)
    except CloneError as exc:
        console.print(f"[red]{exc}[/]")
        sys.exit(1)
    db.upsert_project(p["platform"], p["slug"], local_path=str(dest), status="cloned")
    console.print(f"[green]cloned ->[/] {dest}")


def cmd_audit(args):
    cfg, workspace, db, _ = _ctx(args)
    p = _resolve(db, args.id)
    pdir = project_dir(workspace, p["platform"], p["slug"])
    repo = Path(p["local_path"]) if p["local_path"] else pdir / "repo"
    if not repo.exists():
        console.print("[red]no local repo - run `bh clone` first[/]")
        sys.exit(1)
    stats = repo_stats(repo)
    db.upsert_project(p["platform"], p["slug"], stack=detect_stack(repo), status="auditing")
    audit = run_audit(cfg, repo, RULES_DIR, solidity_mode=bool(list(repo.rglob("*.sol"))))
    console.print(_tool_table(repo.name, audit["tools"]))
    for f in audit["findings"]:
        db.add_finding(p["id"], f)
    for t in audit["tools"]:
        db.add_run(p["id"], t.get("tool", "?"), t.get("status", "?"))
    for path in write_reports(p, audit, cfg, pdir, stats):
        console.print(f"[green]report ->[/] {path}")
    db.set_status(p["id"], "audited")
    console.print(f"{len(audit['findings'])} findings")


def cmd_target(args):
    cfg, workspace, db, session = _ctx(args)
    console.print(f"[cyan]intake[/] {args.url}")
    pid, scope = intake(cfg, db, session, args.url)

    t = Table(title="parsed scope")
    t.add_column("field")
    t.add_column("value", overflow="fold")
    for r in scope["repos"]:
        t.add_row("repo", r["url"])
        for p_ in r["paths"]:
            t.add_row("", f"  path: {p_}")
        if not r["paths"]:
            t.add_row("", "  (whole repository)")
    t.add_row("ladder", "\n".join(f"{s['severity']}: ${s['max_reward']:,}"
                                  for s in scope["severity_table"]) or "-")
    t.add_row("contacts", ", ".join(scope["contacts"]) or "-")
    t.add_row("exclusions", str(len(scope["exclusions"])))
    console.print(t)

    p = db.get_project(str(pid))
    pdir = project_dir(workspace, p["platform"], p["slug"])
    console.print(f"[green]scope ->[/] {save_scope(pdir, scope)}")
    if not args.go:
        console.print("\n[dim]re-run with --go to clone and audit[/]")
        return

    if not os.environ.get(cfg.solidity.get("fork_rpc_env", "ETH_RPC_URL")):
        console.print("[yellow]ETH_RPC_URL unset - PoC scaffolds will not fork[/]")

    root = pdir / "repo"
    findings, cloned, scope_paths = [], [], []
    for r in scope["repos"]:
        name = r["url"].rstrip("/").split("/")[-1].removesuffix(".git")
        dest = root / name
        try:
            clone_repo(r["url"], r["branch"], dest)
            cloned.append(dest)
            scope_paths.extend(r["paths"])
        except CloneError as exc:
            console.print(f"[red]{name}: {exc}[/]")

    prior: list = []
    for dest in cloned:
        prior += find_prior_audits(dest)
    if prior:
        scope["existing_audits"] = prior
        console.print(f"[yellow]{len(prior)} prior audit file(s) in repo - read these first[/]")
        for a in prior[:8]:
            console.print(f"  [dim]{a}[/]")

    for dest in cloned:
        stats = repo_stats(dest)
        console.print(f"[cyan]auditing[/] {dest.name} ({stats['files']} files)")
        res = run_audit(cfg, dest, RULES_DIR, solidity_mode=True, scope_paths=scope_paths)
        console.print(_tool_table(dest.name, res["tools"]))
        for f in res["findings"]:
            f["file"] = f"{dest.name}/{f.get('file') or ''}"
        findings.extend(res["findings"])
        for t_ in res["tools"]:
            db.add_run(pid, t_.get("tool", "?"), t_.get("status", "?"))

    findings.sort(key=lambda x: -x["cvss"])
    for f in findings:
        db.add_finding(pid, f)

    counts = {s: 0 for s in ("critical", "high", "medium", "low", "info")}
    for f in findings:
        counts[f["severity"]] += 1
    audit = {"findings": findings, "counts": counts, "tools": []}

    for path in write_reports(p, audit, cfg, pdir, {"files": 0, "bytes": 0}, scope):
        console.print(f"[green]report ->[/] {path}")
    if cfg.poc.get("enabled", True):
        fallback = None
        for dest in cloned:
            fallback = first_deployment_address(dest)
            if fallback:
                break
        for path in generate(pdir, findings, scope, fallback):
            console.print(f"[green]poc ->[/] {path}")
    db.set_status(pid, "audited")

    if counts["critical"] or counts["high"]:
        console.print(f"\n[yellow]critical {counts['critical']} / high {counts['high']} "
                      f"- validate against the live target before writing up[/]")


def cmd_docs(args):
    cfg, workspace, db, session = _ctx(args)
    res = hunt(cfg, db, session, use_defillama=not args.no_defillama,
               use_gitbook=not args.no_gitbook, use_dorks=not args.no_dorks,
               extra_hosts=args.host or [], limit=args.limit)
    console.print(f"probed {res['hosts_probed']} -> [green]{res['stored']} programs[/]")
    for src, status in res["sources"].items():
        console.print(f"  {src}: {status}")


def cmd_run(args):
    cfg, workspace, db, session = _ctx(args)
    for kw in (args.keyword or cfg.keywords):
        run_discovery(cfg, db, session, kw, use_x=not args.no_x)
    for p in db.list_projects("discovered")[: args.limit]:
        try:
            intel = gather(cfg, session, p, workspace)
            if not intel["repo_url"]:
                db.set_status(p["id"], "no-repo")
                continue
            db.upsert_project(p["platform"], p["slug"], repo_url=intel["repo_url"], status="intel")
            dest = project_dir(workspace, p["platform"], p["slug"]) / "repo" / "src"
            repo = clone_repo(intel["repo_url"], None, dest)
            stats = repo_stats(repo)
            db.upsert_project(p["platform"], p["slug"], local_path=str(repo),
                              stack=detect_stack(repo), status="auditing")
            audit = run_audit(cfg, repo, RULES_DIR, solidity_mode=bool(list(repo.rglob("*.sol"))))
            console.print(_tool_table(repo.name, audit["tools"]))
            for f in audit["findings"]:
                db.add_finding(p["id"], f)
            for path in write_reports(db.get_project(p["id"]), audit, cfg,
                                      project_dir(workspace, p["platform"], p["slug"]), stats):
                console.print(f"[green]{p['slug']} ->[/] {path}")
            db.set_status(p["id"], "audited")
        except Exception as exc:
            db.add_run(p["id"], "pipeline", "error", str(exc))
            db.set_status(p["id"], "error")
            console.print(f"[red]{p['slug']}: {exc}[/]")
            if args.verbose:
                traceback.print_exc()
    console.print(f"[green]index ->[/] {write_index(workspace, db)}")


def build_parser():
    ap = argparse.ArgumentParser(prog="bh")
    ap.add_argument("--config", default="config.yaml")
    ap.add_argument("-v", "--verbose", action="store_true")
    sub = ap.add_subparsers(dest="cmd", required=True)

    p = sub.add_parser("target", help="intake a bounty URL, then clone + audit")
    p.add_argument("url")
    p.add_argument("--go", action="store_true")
    p.set_defaults(func=cmd_target)

    p = sub.add_parser("discover")
    p.add_argument("-k", "--keyword", action="append")
    p.add_argument("--no-x", action="store_true")
    p.set_defaults(func=cmd_discover)

    p = sub.add_parser("docs")
    p.add_argument("--host", action="append")
    p.add_argument("--limit", type=int, default=200)
    p.add_argument("--no-defillama", action="store_true")
    p.add_argument("--no-gitbook", action="store_true")
    p.add_argument("--no-dorks", action="store_true")
    p.set_defaults(func=cmd_docs)

    p = sub.add_parser("links")
    p.add_argument("keyword")
    p.set_defaults(func=cmd_links)

    p = sub.add_parser("list")
    p.add_argument("--status")
    p.set_defaults(func=cmd_list)

    p = sub.add_parser("show")
    p.add_argument("id")
    p.set_defaults(func=cmd_show)

    p = sub.add_parser("clone")
    p.add_argument("id")
    p.set_defaults(func=cmd_clone)

    p = sub.add_parser("audit")
    p.add_argument("id")
    p.set_defaults(func=cmd_audit)

    p = sub.add_parser("run")
    p.add_argument("-k", "--keyword", action="append")
    p.add_argument("--limit", type=int, default=10)
    p.add_argument("--no-x", action="store_true")
    p.set_defaults(func=cmd_run)
    return ap


def main(argv=None):
    console.print(f"[bold cyan]{BANNER}[/]")
    args = build_parser().parse_args(argv)
    try:
        args.func(args)
    except KeyboardInterrupt:
        console.print("\n[yellow]interrupted[/]")
        sys.exit(130)
