from __future__ import annotations

import shutil
from pathlib import Path

from .util import have_tool, log, run_cmd


class CloneError(RuntimeError):
    pass


def clone_repo(repo_url: str, branch, target: Path, blobless: bool = True) -> Path:
    """Full working tree.

    A sparse checkout breaks Solidity builds: in-scope contracts import from
    out-of-scope directories (contracts/interfaces, contracts/common) and from
    lib/. Scope is therefore filtered at report time, not at clone time.
    """
    if not have_tool("git"):
        raise CloneError("git not installed")
    if target.exists():
        shutil.rmtree(target, ignore_errors=True)
    target.parent.mkdir(parents=True, exist_ok=True)

    cmd = ["git", "clone"]
    if blobless:
        cmd += ["--filter=blob:none"]
    if branch:
        cmd += ["--branch", branch]
    cmd += ["--recurse-submodules", repo_url, str(target)]

    res = run_cmd(cmd, timeout=3600)
    if not res["ok"]:
        raise CloneError(res["err"][:800] or res["out"][:800])

    count = sum(1 for _ in target.rglob("*"))
    log.info("cloned %s (%d entries)", target.name, count)
    return target


def sparse_clone(repo_url: str, branch, paths, target: Path, full: bool = False) -> Path:
    """Compatibility shim: paths are ignored, we always take the full tree."""
    return clone_repo(repo_url, branch, target)


def head_sha(repo: Path):
    res = run_cmd(["git", "rev-parse", "HEAD"], cwd=repo)
    return res["out"].strip() if res["ok"] else None
