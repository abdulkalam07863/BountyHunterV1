"""bountyhunter - bounty discovery + deep security audit pipeline."""
__version__ = "1.1.0"
